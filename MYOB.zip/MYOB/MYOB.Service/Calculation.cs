﻿using System;
using System.Collections.Generic;
using System.Linq;
using MYOB.Models;

namespace MYOB.Service
{
    public class Calculation: IIncomeCalculation
    {
        private List<TaxBracketModel> _taxBrackets;

        public Calculation()
        {
            _taxBrackets = new List<TaxBracketModel>();
            LoadTaxes();
        }

        private void LoadTaxes()
        {
            _taxBrackets.Add(new TaxBracketModel
            {
             MinBracket = 1,
             MaxBracket = 18200,
             Cents = (float)0.000,
             TaxAmount = 0,
             
            });

            _taxBrackets.Add(new TaxBracketModel
            {
                MinBracket = 18201,
                MaxBracket = 37000,
                Cents = (float)0.19,
                TaxAmount = 0,

            });

            _taxBrackets.Add(new TaxBracketModel
            {
                MinBracket = 37001,
                MaxBracket = 87000,
                Cents = (float)0.325,
                TaxAmount = 3572,

            });

            _taxBrackets.Add(new TaxBracketModel
            {
                MinBracket = 87001,
                MaxBracket = 180000,
                Cents = (float)0.37,
                TaxAmount = 19822,

            });

            _taxBrackets.Add(new TaxBracketModel
            {
                MinBracket = 180001,
                MaxBracket = 0,
                Cents = (float)0.45,
                TaxAmount = 54232,

            });
        }

        public TaxBracketModel GetTaxDetails(double annualIncomeAmount)
        {
            if (annualIncomeAmount < 0)
                throw new ArgumentException("Annual income amount must be non negative amount");

            if (annualIncomeAmount > 180000)
                return _taxBrackets.Where(t => t.MinBracket == 180001).FirstOrDefault();

            if (annualIncomeAmount == 0)
                return _taxBrackets.Where(t => t.MinBracket == 1).FirstOrDefault();

            return _taxBrackets.Where(t => annualIncomeAmount >= t.MinBracket && annualIncomeAmount <= t.MaxBracket).FirstOrDefault();
        }
        public int CalculateMonthlyGrossIncome(double annualIncomeAmount)
        {
            if (annualIncomeAmount < 0)
                throw new ArgumentException("Annual income amount must be non negative amount");

            return (int)annualIncomeAmount / 12;
        }

        public int CalculateMonthlyIncomeTax(double grossAnnualIncomeAmount, TaxBracketModel taxDetails)
        {
            if (grossAnnualIncomeAmount < 0 || taxDetails == null)
                throw new ArgumentException("Annual income amount must be positive amount & taxDetails cannot be null");

            var incomeTax = (taxDetails.TaxAmount + ((grossAnnualIncomeAmount - (taxDetails.MinBracket - 1)) * taxDetails.Cents)) / 12;
            return (int)Math.Round(incomeTax);
        }

        public int CalculateNetIncome(double grossMonthlyAmount, double incomeTaxAmount)
        {
            if (grossMonthlyAmount < 0 || incomeTaxAmount < 0)
                throw new ArgumentException("gross monthly amount & incomeTaxAmount must be non negative amount");

            return (int)Math.Round((grossMonthlyAmount - incomeTaxAmount));
        }

        public int CalculateMonthlySuper(double grossMonthlyAmount, int superRate)
        {
            if (grossMonthlyAmount < 0)
                throw new ArgumentException("Gross monthly amount must be non negative amount");

            if (superRate < 0)
                throw new ArgumentException("Super rate must be non negative amount");

            float rate = (float)Math.Round((double)superRate/100,2);
            var result = Math.Round(grossMonthlyAmount * rate);
            return (int)result;
        }
    }
}
