﻿using System;
using System.Collections.Generic;
using System.Text;
using Autofac;

namespace MYOB.Service
{
    public class DependencyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.Register(c => new Calculation()).As<IIncomeCalculation>().InstancePerLifetimeScope();
        }
    }
}
