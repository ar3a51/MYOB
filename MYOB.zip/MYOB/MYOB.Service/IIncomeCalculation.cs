﻿using System;
using System.Collections.Generic;
using System.Text;
using MYOB.Models;

namespace MYOB.Service
{
    public interface IIncomeCalculation
    {
        TaxBracketModel GetTaxDetails(double incomeAmount);
        int CalculateMonthlyGrossIncome(double amount);
        int CalculateMonthlyIncomeTax(double amount, TaxBracketModel taxDetails);
        int CalculateNetIncome(double amount, double incomeTaxAmount);
        int CalculateMonthlySuper(double grossAmount, int superRate);
    }
}
