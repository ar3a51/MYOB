using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MYOB.Models;
using MYOB.Service;

namespace MYOB.WebApi.Controllers
{
    [Route("api/[controller]")]
    public class IncomeCalculatorController : Controller
    {

        private IIncomeCalculation _incomeCalculation;
        public IncomeCalculatorController(IIncomeCalculation incomeCalculation)
        {
            _incomeCalculation = incomeCalculation;
        }
       
        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody]InputModel model)
        {
          try
          {
            var incomeTax = _incomeCalculation.CalculateMonthlyIncomeTax(model.AnnualSalary, _incomeCalculation.GetTaxDetails(model.AnnualSalary));
            var monthlyGrossIncome = _incomeCalculation.CalculateMonthlyGrossIncome(model.AnnualSalary);
            var netIncome = _incomeCalculation.CalculateNetIncome(monthlyGrossIncome, incomeTax);

            return Ok(new OutputModel
            {
              MonthlyGrossIncome = monthlyGrossIncome,
              Name = model.FirstName + " " + model.LastName,
              IncomeTax = incomeTax,
              NetIncome = netIncome,
              PayPeriod = model.PaymentPeriod,
              Super = _incomeCalculation.CalculateMonthlySuper(monthlyGrossIncome, model.SuperRate)
            });
          }
          catch(Exception ex)
          {
            return StatusCode(500,ex.Message);
          }
        }
    }
}
