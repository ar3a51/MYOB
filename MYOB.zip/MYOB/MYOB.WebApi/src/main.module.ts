import { NgModule } from '@angular/core';
import { MYOBMainComponent } from './app';
import { AppModule } from './app/app.module';


@NgModule({
  bootstrap: [MYOBMainComponent],
  imports: [AppModule]
})

export class MainModule { }
