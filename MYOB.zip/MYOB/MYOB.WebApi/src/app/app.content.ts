import * as app from '../app';


export const services = [
  app.CalculatorService,
]

export const components = [
  app.MYOBMainComponent,
]
