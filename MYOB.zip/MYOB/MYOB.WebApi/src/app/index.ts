export * from "./myobmain/models/input.model";
export * from "./myobmain/models/output.model";

export * from "./myobmain/services/calculator.service";

export * from "./myobmain/components/myobmain.component";
