import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  async,
  ComponentFixture,
  TestBed,
  ComponentFixtureAutoDetect,
} from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { AppModule } from '../../../app/app.module'
import {
  components,
  services,
} from '../../../app/app.content';

import {
  OutputModel,
  InputModel,
} from '../../../app';
import { defer } from 'rxjs';
import { By } from '@angular/platform-browser'

import { MYOBMainComponent, CalculatorService } from '../../../app';


function asyncData<T>(data: T) {
  return defer(() => Promise.resolve(data));
}

describe('MYOBNavComponent', () => {
  let component: MYOBMainComponent;
  let fixture: ComponentFixture<MYOBMainComponent>;
  let httpClientSpy: { post: jasmine.Spy }
  let service: CalculatorService;
  let result;
  let button;
  let expectedOutput: OutputModel = {
    netIncome: 4082,
    monthlyGrossIncome: 5004,
    payPeriod: "1st of March - 31st of March",
    super: 450,
    incomeTax: 922,
    name: "John Doe"
  }

  let input: InputModel = {
    firstName: "John",
    lastName: "Doe",
    annualSalary: 60050,
    superRate: 9,
    paymentPeriod: "1st of March - 31st of March",
  };

  
  beforeEach(async(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['post']);
    service = new CalculatorService(<any>httpClientSpy);

    httpClientSpy.post.and.returnValue(asyncData(expectedOutput));

    TestBed.configureTestingModule({
      imports: [
        AppModule,
      ],
      providers: [
        { provide: ComponentFixtureAutoDetect, useValue: true },
        { provide: CalculatorService, useValue: service }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MYOBMainComponent);
    component = fixture.componentInstance;
  }));

  it('should compile', () => {
    expect(component).toBeTruthy();
  });

  it('should get output', async(() => {
    
    component.submit();
    fixture.whenStable().then(() => {
      expect(component._output).toBeDefined();
      fixture.detectChanges();
    })
    
  }));
});

