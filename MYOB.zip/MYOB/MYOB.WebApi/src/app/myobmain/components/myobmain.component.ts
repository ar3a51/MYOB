import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  InputModel,
  OutputModel,
  CalculatorService
} from '../../../app';


@Component({
  selector: 'myob-main',
  templateUrl: 'myobmain.component.html',
  styleUrls: ['myobmain.component.scss']
})
export class MYOBMainComponent {

  public _input: InputModel = new InputModel();
  public _output: OutputModel;
  public _errorMessage: string;
  constructor(
    private _calculatorService: CalculatorService
  ) { }

  public submit(): void {
    this._output = null
    this._errorMessage = "";

    this._calculatorService.sendPayload(this._input)
      .subscribe(
      (result: OutputModel) => { this._output = result; },
      (err) => {
        console.log(JSON.stringify(err));
        this._errorMessage = err.error;
      }
      )
  }
}


