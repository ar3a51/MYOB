export class OutputModel {
  public name: string;
  public payPeriod: string;
  public monthlyGrossIncome: number;
  public incomeTax: number;
  public netIncome: number;
  public super: number;
}
