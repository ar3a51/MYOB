export class InputModel {
  public firstName: string;
  public lastName: string;
  public annualSalary: number;

  public superRate: number;
  public paymentPeriod: string;
}
