import { CalculatorService, InputModel, OutputModel } from '../../../app';
import { fakeAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { defer } from 'rxjs';

function asyncData<T>(data: T) {
  return defer(() => Promise.resolve(data));
}

describe("CalculatorService", () => {
  let service: CalculatorService;
  let input: InputModel = {
    firstName: "John",
    lastName: "Doe",
    annualSalary: 60050,
    superRate: 9,
    paymentPeriod: "1st of March - 31st of March",
  };
  let httpClientSpy: { post: jasmine.Spy }

  beforeEach(fakeAsync(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['post']);
    service = new CalculatorService(<any>httpClientSpy);
  }));

  it("#CalculatorService should return output", () => {
    let expectedOutput: OutputModel = {
      netIncome: 4082,
      monthlyGrossIncome: 5004,
      payPeriod: "1st of March - 31st of March",
      super: 450,
      incomeTax: 922,
      name: "John Doe"
    }
    httpClientSpy.post.and.returnValue(asyncData(expectedOutput));

    service.sendPayload(input).subscribe(

      value => expect(value).toEqual(expectedOutput, "expected output"),
      fail
    )
  });
});
