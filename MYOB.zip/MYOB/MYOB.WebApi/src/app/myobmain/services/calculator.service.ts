import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import * as app from '../../../app';

@Injectable()
export class CalculatorService {
  constructor(
    private _http: HttpClient
  )
  { }

  public sendPayload(input: app.InputModel): Observable<any> {
    return this._http.post(`/api/incomecalculator`, input);
  } 


}
