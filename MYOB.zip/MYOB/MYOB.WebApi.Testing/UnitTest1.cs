﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MYOB.WebApi.Testing
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
