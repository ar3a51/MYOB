using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.AspNetCore.Mvc;
using MYOB.Models;
using MYOB.Service;
using MYOB.WebApi.Controllers;
using AutoFixture;
using AutoFixture.Kernel;

namespace MYOB.WebApi.Test
{
    [TestClass]
    public class WebApiIntegrationTest
    {
        private IncomeCalculatorController _incomeCalculatorController;

        [TestInitialize]
        public void initialise()
        {
            _incomeCalculatorController = new IncomeCalculatorController(new Calculation());
        }
        [TestMethod]
        public void TestSuccessScenario()
        {
            InputModel inputModel = new InputModel {
             AnnualSalary = 60050,
             FirstName = "John",
             LastName = "Doe",
             PaymentPeriod = "1 March - 31 March",
             SuperRate = 9
            };

          var result =  _incomeCalculatorController.Post(inputModel) as OkObjectResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
        }

        [TestMethod]
        public void TestFailedScenario()
        {
            InputModel inputModel = new InputModel
            {
                AnnualSalary = -60050,
                FirstName = "John",
                LastName = "Doe",
                PaymentPeriod = "1 March - 31 March",
                SuperRate = -9
            };

            var result = _incomeCalculatorController.Post(inputModel) as OkObjectResult;

            Assert.IsNull(result);
            
        }
    }
}
