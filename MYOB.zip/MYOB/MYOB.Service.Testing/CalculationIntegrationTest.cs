﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MYOB.Models;
using MYOB.Service;

namespace MYOB.Service.Testing
{
    [TestClass]
    public class CalculationIntegrationTest
    {
        private Calculation _calculation;

        [TestInitialize]
        public void Init()
        {
            _calculation = new Calculation();
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxBotomBracket0to18200()
        {
            double grossAnnualIncome = 0;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);

            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxMidBracket0to18200()
        {
            double grossAnnualIncome = 10000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);

            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxTopBracket0to18200()
        {
            double grossAnnualIncome = 18200;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);

            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }


        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxBottomBracket18201to37000()
        {
            double grossAnnualIncome = 18201;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxMidBracket18201to37000()
        {
            double grossAnnualIncome = 20000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(26, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxTopBracket18201to37000()
        {
            double grossAnnualIncome = 37000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(294, result,10, String.Format("actual {0}", result));
        }


        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxBottomBracket37001to87000()
        {
            double grossAnnualIncome = 37001;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(294, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxMidBracket37001to87000()
        {
            double grossAnnualIncome = 60050;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(922, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxTopBracket37001to87000()
        {
            double grossAnnualIncome = 87000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossAnnualIncome);
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(1657, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxBottomBracket87001to180000()
        {
            double GrossAnnual = 87001;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(GrossAnnual);
            int result = _calculation.CalculateMonthlyIncomeTax(GrossAnnual, taxBracketModel);

            Assert.AreEqual(1657, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxMidBracket87001to180000()
        {
            double GrossAnnual = 90000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(GrossAnnual);
            int result = _calculation.CalculateMonthlyIncomeTax(GrossAnnual, taxBracketModel);

            Assert.AreEqual(1748, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxTopBracket87001to180000()
        {
            double GrossAnnual = 180000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(GrossAnnual);
            int result = _calculation.CalculateMonthlyIncomeTax(GrossAnnual, taxBracketModel);

            Assert.AreEqual(4523, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateIncomeTaxGreater180000()
        {
            double GrossAnnual = 200000;
            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(GrossAnnual);
            int result = _calculation.CalculateMonthlyIncomeTax(GrossAnnual, taxBracketModel);

            Assert.AreEqual(5274, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestIntegrationCalculateNetIncomeTest()
        {
            double grossIncome = 60050;
            var grossIncomeMonthly = this._calculation.CalculateMonthlyGrossIncome(grossIncome);

            TaxBracketModel taxBracketModel = _calculation.GetTaxDetails(grossIncome);
            var incomeTax = _calculation.CalculateMonthlyIncomeTax(grossIncome, taxBracketModel);

            var netMonthlyIncome = _calculation.CalculateNetIncome(grossIncomeMonthly, incomeTax);
            Assert.AreEqual(4082, netMonthlyIncome, String.Format("Actual {0}", netMonthlyIncome));
        }

        [TestMethod]
        public void TestIntegrationCalculateSuper()
        {
            double yearlyGrossIncome = 60050;
            int superRate = 9;
            var monthlyIncome = this._calculation.CalculateMonthlyGrossIncome(yearlyGrossIncome);

            var monthlySuper = this._calculation.CalculateMonthlySuper(monthlyIncome, superRate);

            Assert.AreEqual(450, monthlySuper, 10, string.Format("actual {0}", monthlySuper));
        }
    }
}
