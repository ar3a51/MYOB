﻿using System;
using MYOB.Models;
using MYOB.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MYOB.Service.Testing
{
    [TestClass]
    public class CalculationTest
    {
        private Calculation _calculation;

        [TestInitialize]
        public void Init()
        {
            _calculation = new Calculation();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestGetTaxDetailsException()
        {
            _calculation.GetTaxDetails(-1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateGrossIncomeException()
        {
            _calculation.CalculateMonthlyGrossIncome(-1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateIncomeTaxExceptionTaxDetailsNull()
        {
            _calculation.CalculateMonthlyIncomeTax(300, null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateIncomeTaxExceptionAmountZero()
        {
            _calculation.CalculateMonthlyIncomeTax(-1, new TaxBracketModel());
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateIncomeTaxExceptionBothNothing()
        {
            _calculation.CalculateMonthlyIncomeTax(-1,null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateNetIncomeBothNothing()
        {
            _calculation.CalculateNetIncome(-1, -1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateNetIncomeAmountZero()
        {
            _calculation.CalculateNetIncome(-1, 1234);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateNetIncomeNegativeTaxAmount()
        {
            _calculation.CalculateNetIncome(1234, -1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateSuperBothNothing()
        {
            _calculation.CalculateMonthlySuper(-1, -1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateSuperGrossAmountNothing()
        {
            _calculation.CalculateMonthlySuper(-1, 9);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestCalculateSuperSuperRateNothing()
        {
            _calculation.CalculateMonthlySuper(345345, -1);
        }

        [TestMethod]
        public void TestCalculateMonthlyGrossIncome()
        {
            double input = 60050;
            int result = _calculation.CalculateMonthlyGrossIncome(input);


            Assert.AreEqual(5004, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestGetTaxDetailBottomBracket0to18200()
        {
            double annualIncomeAmount = 0;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(0, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual(1, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(18200, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(0, res.Cents, String.Format("actual {0}", res.Cents));
        }

        [TestMethod]
        public void TestGetTaxDetailMidBracket0to18200()
        {
            double annualIncomeAmount = 9100;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(0, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual(1, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(18200, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(0, res.Cents, String.Format("actual {0}", res.Cents));
        }

        [TestMethod]
        public void TestGetTaxDetailTopBracket0to18200()
        {
            double annualIncomeAmount = 18200;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(0, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual(1, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(18200, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(0, res.Cents, String.Format("actual {0}", res.Cents));
        }

        [TestMethod]
        public void TestGetTaxDetaillowestBracket18201to37000()
        {
            double annualIncomeAmount = 18201;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual((float)0.19, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(37000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(18201, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(0, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
        }

        [TestMethod]
        public void TestGetTaxDetailMidBracket18201to37000()
        {
            double annualIncomeAmount = 18500;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual((float)0.19, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(37000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(18201, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(0, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
        }

        [TestMethod]
        public void TestGetTaxDetailTopBracket18201to37000()
        {
            double annualIncomeAmount = 37000;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual((float)0.19, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(37000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(18201, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(0, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
        }

        [TestMethod]
        public void TestGetTaxDetailBottomBracket37001to87000()
        {
            double annualIncomeAmount = 37001;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(3572, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.325, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(37001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(87000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }

        [TestMethod]
        public void TestGetTaxDetailMidBracket37001to87000()
        {
            double annualIncomeAmount = 60050;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(3572, res.TaxAmount, String.Format("actual {0}",res.TaxAmount));
            Assert.AreEqual((float)0.325, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(87000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
            Assert.AreEqual(37001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
        }

        [TestMethod]
        public void TestGetTaxDetailTopBracket37001to87000()
        {
            double annualIncomeAmount = 87000;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(3572, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.325, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(37001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(87000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }

        [TestMethod]
        public void TestGetTaxDetailBottomBracket870001to180000()
        {
            double annualIncomeAmount = 180000;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(19822, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.37, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(87001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(180000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }

        [TestMethod]
        public void TestGetTaxDetailMidBracket870001to180000()
        {
            double annualIncomeAmount = 90000;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(19822, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.37, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(87001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(180000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }


        [TestMethod]
        public void TestGetTaxDetailTopBracket870001to180000()
        {
            double annualIncomeAmount = 180000;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(19822, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.37, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(87001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(180000, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }

        [TestMethod]
        public void TestGetTaxDetailBottomBracket180001AndOver()
        {
            double annualIncomeAmount = 180001;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(54232, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.45, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(180001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(0, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }

        [TestMethod]
        public void TestGetTaxDetailMidBracket180001AndOver()
        {
            double annualIncomeAmount = 250000;
            var res = _calculation.GetTaxDetails(annualIncomeAmount);
            Assert.AreEqual(54232, res.TaxAmount, String.Format("actual {0}", res.TaxAmount));
            Assert.AreEqual((float)0.45, res.Cents, String.Format("actual {0}", res.Cents));
            Assert.AreEqual(180001, res.MinBracket, String.Format("actual {0}", res.MinBracket));
            Assert.AreEqual(0, res.MaxBracket, String.Format("actual {0}", res.MaxBracket));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxBottomBracket0to18200()
        {
            double grossAnnualIncome = 0;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 1,
                MaxBracket = 18200,
                Cents = (float)0.000,
                TaxAmount = 0,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxMidBracket0to18200()
        {
            double grossAnnualIncome = 17000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 1,
                MaxBracket = 18200,
                Cents = (float)0.000,
                TaxAmount = 0,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxTopBracket0to18200()
        {
            double grossAnnualIncome = 18200;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 1,
                MaxBracket = 18200,
                Cents = (float)0.000,
                TaxAmount = 0,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }


        [TestMethod]
        public void TestCalculateIncomeTaxBottomBracket18201to37000()
        {
            double grossAnnualIncome = 18201;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 18201,
                MaxBracket = 37000,
                Cents = (float)0.19,
                TaxAmount = 0,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(0, result, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxMidBracket18201to37000()
        {
            double grossAnnualIncome = 30000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 18201,
                MaxBracket = 37000,
                Cents = (float)0.19,
                TaxAmount = 0,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(184, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxTopBracket18201to37000()
        {
            double grossAnnualIncome = 37000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 18201,
                MaxBracket = 37000,
                Cents = (float)0.19,
                TaxAmount = 0,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(293, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxBottomBracket37001to87000()
        {
            double grossAnnualIncome = 37001;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                Cents = (float)0.325,
                MinBracket = 37001,
                MaxBracket = 87000,
                TaxAmount = 3572
            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(293, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxMidBracket37001to87000()
        {
            double grossAnnualIncome = 60050;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                Cents = (float)0.325,
                MinBracket = 37001,
                MaxBracket = 87000,
                TaxAmount = 3572
            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(922, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxTopBracket37001to87000()
        {
            double grossAnnualIncome = 87000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                Cents = (float)0.325,
                MinBracket = 37001,
                MaxBracket = 87000,
                TaxAmount = 3572
            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(1657, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxBottomBracket87001to180000()
        {
            double grossAnnualIncome = 87001;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 87001,
                MaxBracket = 180000,
                Cents = (float)0.37,
                TaxAmount = 19822,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(1657, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxMidBracket87001to180000()
        {
            double grossAnnualIncome = 90000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 87001,
                MaxBracket = 180000,
                Cents = (float)0.37,
                TaxAmount = 19822,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(1748, result, 10, String.Format("actual {0}", result));
        }

        [TestMethod]
        public void TestCalculateIncomeTaxTopBracket87001to180000()
        {
            double grossAnnualIncome = 180000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                MinBracket = 87001,
                MaxBracket = 180000,
                Cents = (float)0.37,
                TaxAmount = 19822,

            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(4523, result, 10, String.Format("actual {0}", result));
        }

      
        [TestMethod]
        public void TestCalculateIncomeTaxGreater180000()
        {
            double grossAnnualIncome = 200000;
            TaxBracketModel taxBracketModel = new TaxBracketModel
            {
                Cents = (float)0.45,
                MinBracket = 180001,
                MaxBracket = 0,
                TaxAmount = 54232
            };
            int result = _calculation.CalculateMonthlyIncomeTax(grossAnnualIncome, taxBracketModel);

            Assert.AreEqual(5274, result, 10, String.Format("actual {0}", result));
           
        }

        [TestMethod]
        public void TestCalculateNetIncome()
        {
            double grossIncomeMonthly = 5004;
            double incomeTaxAmount = 922;
            int result = _calculation.CalculateNetIncome(grossIncomeMonthly, incomeTaxAmount);

            Assert.AreEqual(4082, result, String.Format("actual {0}",result));
        }

        [TestMethod]
        public void TestCalculateSuper()
        {
            double GrossIncomeMonthly = 2009;
            int superRate = 9;
            int result = _calculation.CalculateMonthlySuper(GrossIncomeMonthly, superRate);
            
            Assert.AreEqual(180, result, 10, String.Format("actual: {0}", result));
        }
    }
}
