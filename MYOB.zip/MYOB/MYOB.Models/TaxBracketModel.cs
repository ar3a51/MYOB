﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MYOB.Models
{
    public class TaxBracketModel
    {
        public int MinBracket{set;get;}
        public int MaxBracket { set; get; }
        public int TaxAmount { set; get; }
        public float Cents { set; get; }
    }
}
