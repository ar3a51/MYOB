﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MYOB.Models
{
    public class InputModel
    {
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public int AnnualSalary { set; get; }

        public int SuperRate { set; get; }
        public string PaymentPeriod { set; get; }
    }
}
