﻿using System;

namespace MYOB.Models
{
    public class OutputModel
    {
        public string Name { set; get; }
        public string PayPeriod { set; get; }
        public int MonthlyGrossIncome { set; get; }
        public int IncomeTax { set; get; }
        public int NetIncome { set; get; }
        public int Super { set; get; }
    }
}
